#include "MalRob_FG.h"

/*
-----------------------------------------------------------------------------------------
*/

Led::Led(uint8_t p_pin_number)
{
  m_pin_number = p_pin_number;
  //ledcSetup(0, 5000, 8);
  //ledcAttachPin(PO_LED, 0);
  pinMode(m_pin_number, OUTPUT);
};

void Led::set_brightness(uint8_t p_brightness_in_percent)
{
  uint8_t mapped_brightness = map(p_brightness_in_percent, 0, 100, 0, 255);
  ledcWrite(0, mapped_brightness);
};

void Led::turn_on()
{
  digitalWrite(m_pin_number, HIGH);
};

void Led::turn_off()
{
  digitalWrite(m_pin_number, LOW);
}

/*
-----------------------------------------------------------------------------------------
*/


Switch::Switch(uint8_t p_pin_number)
{
  m_pin_number = p_pin_number;
  m_state = SWITCH_RELEASED;
  pinMode(m_pin_number, INPUT_PULLUP);
};

bool Switch::get_state()
{
  m_state = digitalRead(m_pin_number);
  return m_state;
};

/*
-----------------------------------------------------------------------------------------
*/

Pen::Pen()
{
  m_offset_in_deg = 0;
  attach(PO_SERVO_MOTOR, 1000, 2000);
};
void Pen::lift()
{
  write(180);
};

void Pen::lower()
{
  write(m_offset_in_deg);
};

void Pen::set_position_without_offset(uint8_t p_position_in_percent)
{
  uint8_t mapped_position = map(p_position_in_percent, 0, 100, 0, 180);
  write(mapped_position);
};

void Pen::set_position_with_offset(uint8_t p_position_in_percent)
{
  uint8_t mapped_position = map(p_position_in_percent, 0, 100, m_offset_in_deg, 180);
  write(mapped_position);
};

/*
-----------------------------------------------------------------------------------------
*/


Motors::Motors()
{
  attachMotors(PO_LEFT_MOTOR_A1, PO_LEFT_MOTOR_A2, PO_RIGHT_MOTOR_B1, PO_RIGHT_MOTOR_B2);
}


void Motors::move_forward(uint8_t p_selection, uint8_t p_speed)
{
  switch(p_selection)
  {
    case MOTOR_LEFT:
      motorForward(0, p_speed);
      break;
      
    case MOTOR_RIGHT:
      motorReverse(1, p_speed);
      break;
      
    case MOTOR_BOTH:
      motorForward(0, p_speed);
      motorReverse(1, p_speed);
      break;

    default:
      break;
  };
};


void Motors::move_reverse(uint8_t p_selection, uint8_t p_speed)
{
  switch(p_selection)
  {
    case MOTOR_LEFT:
      motorReverse(0, p_speed);
      break;
      
    case MOTOR_RIGHT:
      motorForward(1, p_speed);
      break;
      
    case MOTOR_BOTH:
      motorReverse(0, p_speed);
      motorForward(1, p_speed);
      break;

    default:
      break;
  };
};


// MAYBE AS FLOAT?!
// IMPLEMENT SPEED IN BLOCKLY
void Motors::move_forward_in_revolutions(uint8_t p_selection, uint8_t p_speed, uint16_t p_revolutions)
{
  bool finished_revolutions = false;
  move_forward(p_selection, p_speed);
  do
  {
    finished_revolutions = check_for_finished_revolutions(p_revolutions);
  } while(!finished_revolutions);
}

void Motors::move_reverse_in_revolutions(uint8_t p_selection, uint8_t p_speed, uint16_t p_revolutions)
{
  bool finished_revolutions = false;
  move_reverse(p_selection, p_speed);
  do
  {
    finished_revolutions = check_for_finished_revolutions(p_revolutions);
  } while(!finished_revolutions);
}

void Motors::stop_motor(uint8_t p_selection)
{
  switch(p_selection)
  {
    case MOTOR_LEFT:
      motorStop(0);
      break;
      
    case MOTOR_RIGHT:
      motorStop(1);
      break;
      
    case MOTOR_BOTH:
      motorStop(0);
      motorStop(1);
      break;

    default:
      break;
}
};

