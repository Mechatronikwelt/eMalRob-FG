

//#ifndef "_MALROB_FG_H_"
//#define "_MALROB_FG_H_"

#include <Arduino.h>
#include "ESP32MotorControl.h"   // https://github.com/JoaoLopesF/ESP32MotorControl
//#include <ESP32_Servo.h>	 // falsche Bezeichnung (Unterstrich nicht notwendig) korrekte include folgend
#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// defintion of motor driver DRV8833 control pins
#define PO_LEFT_MOTOR_A1 16      // PWM!
#define PO_LEFT_MOTOR_A2 17      // PWM!
#define PO_RIGHT_MOTOR_B1 4    // PWM!
#define PO_RIGHT_MOTOR_B2 2    // PWM!

// defintion of servo motor for pen
#define PO_SERVO_MOTOR 15      // PWM!

// definition of LED pin
#define PO_LED 27

// definition of limit switches (FL = Front Left, RL= Rear Right)

#define PI_LIMIT_SWITCH_FL 35
#define PI_LIMIT_SWITCH_FR 3
#define PI_LIMIT_SWITCH_RL 4
#define PI_LIMIT_SWITCH_RR 6

// defintion of I2C bus pins for OLED_SS1306
#define P_I2C_SCL 22
#define P_I2C_SDA 21

enum motor_selection {MOTOR_LEFT, MOTOR_RIGHT, MOTOR_BOTH};
enum limit_switch_position {SWITCH_PRESSED, SWITCH_RELEASED};

class Led
{
  private:
    uint8_t m_pin_number;
    uint8_t m_brightness;
    
  public:
      Led(uint8_t p_pin_number);
      void set_brightness(uint8_t p_brightness_in_percent);
      void turn_on();
      void turn_off();
};

class Pen: Servo
{
  public:
    Pen();
    void lift();
    void lower();
    void set_position_without_offset(uint8_t p_position_in_percent);
    void set_position_with_offset(uint8_t p_position_in_percent);
    
  private:
    uint8_t m_offset_in_deg;
};

class Motors: public ESP32MotorControl
{
  public:
    Motors();
    void move_forward(uint8_t p_selection, uint8_t p_speed);
    void move_reverse(uint8_t p_selection, uint8_t p_speed);
    void move_forward_in_revolutions(uint8_t p_selection, uint8_t p_speed, uint16_t p_revolutions);
    void move_reverse_in_revolutions(uint8_t p_selection, uint8_t p_speed, uint16_t p_revolutions);
    void stop_motor(uint8_t p_selection);
    bool check_for_finished_revolutions(uint16_t &p_revolutions);
};

class Switch
{
  private:
    uint8_t m_pin_number;
    uint8_t m_state;
  public:
    Switch();
    Switch(uint8_t p_pin_number);
    bool get_state();
};


//#endif
