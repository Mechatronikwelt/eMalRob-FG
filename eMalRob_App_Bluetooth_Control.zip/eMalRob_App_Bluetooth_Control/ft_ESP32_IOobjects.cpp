/*
Ausgangstreiber für ESP32-Fischertechnik-Anbindung
Autor: Johannes Marquart
*/
#include "ft_ESP32_IOobjects.h"

Motor::Motor()
{
	pinMode(DRIVER_ENABLEPIN, OUTPUT);                                                           //set enablepin as output
	digitalWrite(DRIVER_ENABLEPIN, LOW);                                                         //disable enablepin
  mMotorNr = 0;                                                                                //default value
}

Motor::Motor(int pMotorNr)
{
  pinMode(DRIVER_ENABLEPIN, OUTPUT);                                                           //set enablepin as output
  digitalWrite(DRIVER_ENABLEPIN, LOW);                                                         //disable enablepin
  mMotorNr = pMotorNr;                                                                         //set MotorNr
}

void Motor::driveForwardBackward(int pDrehzahl)
{
  digitalWrite(DRIVER_ENABLEPIN, LOW);
  int drehzahl_pwm = 0;

  if (pDrehzahl>=0)                                                                            //drive forward or stand still
  {
    if (pDrehzahl < 1)                                                                         //calculate the pwm
    {
      drehzahl_pwm = 0;
    }
    else if (pDrehzahl >7)
    {
     drehzahl_pwm = 255;
    }
    else
    {
      drehzahl_pwm = 170 + pDrehzahl * 85 / 8;
    }
    
    if(mMotorNr == 0)
    {
      //analogWrite(PORT_M_0[1],0);                                                               //set the pins of both motors
      //analogWrite(PORT_M_0[0],drehzahl_pwm);
      //Direction
      ledcAttachPin(PORT_M_0[1], 1);  
      ledcSetup(1, 21700, 8);
      ledcWrite(1,0);
      //Speed
      ledcAttachPin(PORT_M_0[0],0);
      ledcSetup(0, 21700, 8);
      ledcWrite(0,drehzahl_pwm);
    }
    else if (mMotorNr == 1)
    {
      //analogWrite(PORT_M_1[1],0);
      //analogWrite(PORT_M_1[0],drehzahl_pwm);
      //Direction
      ledcAttachPin(PORT_M_1[1], 3);  
      ledcSetup(3, 21700, 8);
      ledcWrite(3,0);
      //Speed
      ledcAttachPin(PORT_M_1[0],2);
      ledcSetup(2, 21700, 8);
      ledcWrite(2,drehzahl_pwm);
    }
  }
  else if (pDrehzahl<0)                                                                       //drive backward
  {
    pDrehzahl = abs(pDrehzahl);
    if (pDrehzahl>0)
    {
      if (pDrehzahl < 1)                                                                      //calculate the pwm
      {
        drehzahl_pwm = 0;
      }
      else if (pDrehzahl >7)
      {
        drehzahl_pwm = 255;
      }
      else
      {
        drehzahl_pwm = 170 + pDrehzahl * 85 / 8;
      }

    if(mMotorNr == 0)
    {
      //analogWrite(PORT_M_0[0],0);                                                               //set the pins of both motors
      //analogWrite(PORT_M_0[1],drehzahl_pwm);
      //Direction
      ledcAttachPin(PORT_M_0[0], 1);  
      ledcSetup(1, 21700, 8);
      ledcWrite(1,0);
      //Speed
      ledcAttachPin(PORT_M_0[1],0);
      ledcSetup(0, 21700, 8);
      ledcWrite(0,drehzahl_pwm);
    }
    else if (mMotorNr == 1)
    {
      //analogWrite(PORT_M_1[0],0);
      //analogWrite(PORT_M_1[1],drehzahl_pwm);
      //Direction
      ledcAttachPin(PORT_M_1[0], 3);  
      ledcSetup(3, 21700, 8);
      ledcWrite(3,0);
      //Speed
      ledcAttachPin(PORT_M_1[1],2);
      ledcSetup(2, 21700, 8);
      ledcWrite(2,drehzahl_pwm);
    }
   }
  }
  digitalWrite(DRIVER_ENABLEPIN, HIGH);                                                       //enable motor driver
};

/*CServoMotor::CServoMotor()
{
	mMinDuty = 4;
	mMaxDuty = 11;
	mRelDuty = 0;
}*/

CServoMotor::CServoMotor(unsigned int dutyCycle)
{
	mMinDuty = 4;
	mMaxDuty = 11;
	//mRelDuty = dutyCycle < 100 ? dutyCycle : 100;
  mRelDuty = dutyCycle;
}

void CServoMotor::setValues(unsigned int dutyCycle)
{
	//mRelDuty = dutyCycle < 100 ? dutyCycle : 100;
  mRelDuty = dutyCycle;
  ledcAttachPin(SERVOPIN, 4);
  ledcSetup(4, 50, 12);
	ledcWrite(4, (4095 * (100 * mMinDuty + (mMaxDuty - mMinDuty) * mRelDuty)) / 10000);	
}
