/*
Ausgangstreiber für ESP32-Fischertechnik-Anbindung
Autor: Johannes Marquart

Editiert von WS18/19
*/
#ifndef FT_ESP32_IOOBJECTS_H
#define FT_ESP32_IOOBJECTS_H

#include <Arduino.h>
#include <analogWrite.h>

const int PORT_M_0[2] = {17,16};                                                                  //Motor 0, AIN1 = 17, AIN2 = 16
const int PORT_M_1[2] = {2,4};                                                                    //Motor 1, AIN1 = 4,  AIN2 = 2
const int DRIVER_ENABLEPIN = 27;                                                                  //initialise the enablepin of the motordriver 

const int SERVOPIN = 13;                                                                          //Servo is connected to GPIO 13

class Motor
{
public:
	Motor();	                                                                                      //constructor
	Motor(int pMotorNr);  
	void driveForwardBackward(int pDrehzahl);	                                            
private:
  int mMotorNr;
};

class CServoMotor
{
public:
  //CServoMotor();
	CServoMotor(unsigned int dutyCycle = 50);                                                       //constructor, default dutycycle is 50
	void setValues(unsigned int dutyCycle);	                                                        //set motor values
private:
  unsigned int mMinDuty;
  unsigned int mMaxDuty;
  unsigned int mRelDuty;
};

#endif
